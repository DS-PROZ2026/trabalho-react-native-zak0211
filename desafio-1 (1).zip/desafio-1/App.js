 import React, { useState } from 'react';

// 1. IMPORTAMOS O COMPONENTE IMAGE AQUI:
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image } from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'Qual componente é responsável por transmitir a força do motor para as rodas?',
    opcoes: ['Alternador', 'Sistema de Transmissão', 'Carburador', 'Radiador'],
    respostaCerta: 1,
    imagem: 'https://images.unsplash.com/photo-1517524206127-48bbd363f3d7?w=500'
  },
  {
    id: 2,
    pergunta: 'De quanto em quanto tempo (ou quilometragem) geralmente se recomenda checar ou trocar o óleo do motor?',
    opcoes: ['A cada 50.000 km', 'Apenas quando o motor falhar', 'A cada 5.000 km a 10.000 km', 'Nunca precisa trocar'],
    respostaCerta: 2,
    imagem: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=500'
  },
  {
    id: 3,
    pergunta: 'Qual dessas peças faz parte do sistema de frenagem do veículo?',
    opcoes: ['Pistão', 'Pastilha de freio', 'Biela', 'Vela de ignição'],
    respostaCerta: 1,
    imagem: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?w=500'
  },
  {
    id: 4,
    pergunta: 'Qual é a função principal do radiador no sistema de um automóvel?',
    opcoes: ['Resfriar o motor', 'Gerar eletricidade', 'Aumentar a velocidade', 'Filtrar o combustível'],
    respostaCerta: 0,
    imagem: 'https://images.unsplash.com/photo-1617469167446-8043d4469b88?w=500'
  },
  {
    id: 5,
    pergunta: 'O que a fumaça preta saindo do escapamento geralmente indica?',
    opcoes: ['Combustão perfeita', 'Queima excessiva de combustível', 'Vazamento de água', 'Falta de óleo'],
    respostaCerta: 1,
    imagem: 'https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=500'
  },
  {
    id: 6,
    pergunta: 'Qual componente gera a faísca inicial para queimar a mistura de ar e combustível nos motores a gasolina?',
    opcoes: ['Bateria', 'Alternador', 'Vela de ignição', 'Bomba de combustível'],
    respostaCerta: 2,
    imagem: 'https://images.unsplash.com/photo-1538332360877-bb84f932e65d?w=500'
  },
  {
    id: 7,
    pergunta: 'Qual destas peças reduz o impacto das irregularidades das vias na carroceria do carro?',
    opcoes: ['Amortecedor', 'Discos de freio', 'Cardan', 'Cárter'],
    respostaCerta: 0,
    imagem: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=500'
  },
  {
    id: 8,
    pergunta: 'Qual é a principal função do óleo lubrificante no motor?',
    opcoes: ['Aumentar o consumo de combustível', 'Reduzir o atrito entre as peças móveis', 'Lavar o motor por fora', 'Esquentar o sistema rapidamente'],
    respostaCerta: 1,
    imagem: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=500'
  },
  {
    id: 9,
    pergunta: 'O que o termo "Alinhamento" corrige no comportamento do veículo?',
    opcoes: ['A potência do motor', 'A velocidade máxima', 'O ângulo das rodas para evitar desgaste irregular', 'O brilho dos faróis'],
    respostaCerta: 2,
    imagem: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=500'
  },
  {
    id: 10,
    pergunta: 'Qual instrumento no painel do carro mede as rotações por minuto (RPM) do motor?',
    opcoes: ['Velocímetro', 'Odômetro', 'Tacômetro (ou Conta-giros)', 'Termômetro'],
    respostaCerta: 2,
    imagem: 'https://images.unsplash.com/photo-1562141989-c5c79ac8f576?w=500'
  }
];

export default function AppQuiz() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);
  const [respondido, setRespondido] = useState(false);
  const [opcaoSelecionada, setOpcaoSelecionada] = useState(null);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setRespondido(false);
    setOpcaoSelecionada(null);
    setTelaAtual('quiz');
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indiceClicado) {
    if (respondido) return;

    setRespondido(true);
    setOpcaoSelecionada(indiceClicado);

    const pergunta = QUIZ[perguntaAtual];

    if (indiceClicado === pergunta.respostaCerta) {
      setPontuacao(pontuacao + 1);
    }

    setTimeout(() => {
      setCarregando(true);

      setTimeout(() => {
        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual(perguntaAtual + 1);
          setRespondido(false);
          setOpcaoSelecionada(null);
        } else {
          setTelaAtual('resultado');
        }
        setCarregando(false);
      }, 1500);

    }, 1000);
  }

  // ==========================================
  // AS TELAS
  // ==========================================

  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        {/* 2. EXEMPLO PRÁTICO DE IMAGEM: */}
        {/* Repare nas chaves duplas {{ }} usadas para passar o link da Internet */}
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=500' }}
          style={styles.logoInicial}
        />

        <Text style={styles.tituloPrincipal}>Quiz da Mecânica</Text>
        <Text style={styles.subtituloInicio}>Teste seus conhecimentos sobre o funcionamento de automóveis!</Text>

        <TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo} activeOpacity={0.8}>
          <Text style={styles.textoBotaoIniciar}>INICIAR JOGO</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (telaAtual === 'resultado') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.iconeGrande}>🏆</Text>
        <Text style={styles.titulo}>Fim de Jogo!</Text>
        <Text style={styles.subtitulo}>Você acertou {pontuacao} de {QUIZ.length} perguntas.</Text>

        <TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio} activeOpacity={0.8}>
          <Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.textoCarregando}>Validando resposta...</Text>
      </View>
    );
  }

  const pergunta = QUIZ[perguntaAtual];

  const obterEstiloBotao = (index) => {
    if (!respondido) return styles.botaoOpcao;

    if (index === opcaoSelecionada) {
      return index === pergunta.respostaCerta 
        ? [styles.botaoOpcao, styles.botaoCorreto]   
        : [styles.botaoOpcao, styles.botaoIncorreto]; 
    }

    if (index === pergunta.respostaCerta) {
      return [styles.botaoOpcao, styles.botaoCorreto];
    }

    return styles.botaoOpcao;
  };

  const obterEstiloTexto = (index) => {
    if (respondido && (index === opcaoSelecionada || index === pergunta.respostaCerta)) {
      return [styles.textoOpcao, { color: 'white' }];
    }
    return styles.textoOpcao;
  };

  return (
    <View style={styles.tela}>
      <View style={styles.cabecalho}>
        <Text style={styles.progresso}>Pergunta {perguntaAtual + 1} de {QUIZ.length}</Text>
        <Text style={styles.pontos}>Pontos: {pontuacao}</Text>
      </View>

      {pergunta.imagem && (
        <Image 
          source={{ uri: pergunta.imagem }} 
          style={styles.imagemPergunta} 
        />
      )}

      <View style={styles.cartaoPergunta}>
        <Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
      </View>

      <View style={styles.areaOpcoes}>
        {pergunta.opcoes.map((opcao, index) => (
          <TouchableOpacity
            key={index}
            style={obterEstiloBotao(index)}
            onPress={() => responder(index)}
            disabled={respondido}
            activeOpacity={0.7}
          >
            <Text style={obterEstiloTexto(index)}>{opcao}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// ==========================================
// ESTILOS
// ==========================================

const styles = StyleSheet.create({
  tela: { 
    flex: 1, 
    backgroundColor: '#f8fafc', 
    padding: 20, 
    paddingTop: 60 
  },
  telaCentrada: { 
    flex: 1, 
    backgroundColor: '#f8fafc', 
    justifyContent: 'center', 
    alignItems: 'center', 
    padding: 20 
  },

  // 3. ESTILO DA IMAGEM
  logoInicial: { 
    width: 120, 
    height: 120, 
    marginBottom: 20, 
    borderRadius: 60 
  },
  imagemPergunta: { 
    width: '100%', 
    height: 160, 
    borderRadius: 15, 
    marginBottom: 20, 
    resizeMode: 'cover' 
  },

  tituloPrincipal: { 
    fontSize: 36, 
    fontWeight: '900', 
    color: '#1e293b', 
    marginBottom: 10, 
    textAlign: 'center' 
  },
  subtituloInicio: { 
    fontSize: 16, 
    color: '#64748b', 
    marginBottom: 50, 
    textAlign: 'center', 
    paddingHorizontal: 20 
  },
  botaoIniciar: { 
    backgroundColor: '#10b981', 
    paddingVertical: 20, 
    paddingHorizontal: 40, 
    borderRadius: 20, 
    width: '100%', 
    maxWidth: 300, 
    shadowColor: '#10b981', 
    shadowOpacity: 0.4, 
    shadowRadius: 15, 
    elevation: 8, 
    alignItems: 'center' 
  },
  textoBotaoIniciar: { 
    color: 'white', 
    fontSize: 20, 
    fontWeight: '900', 
    letterSpacing: 1 
  },

  cabecalho: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginBottom: 30, 
    paddingHorizontal: 10 
  },
  progresso: { 
    fontSize: 16, 
    fontWeight: '700', 
    color: '#64748b' 
  },
  pontos: { 
    fontSize: 16, 
    fontWeight: '800', 
    color: '#3b82f6' 
  },

  cartaoPergunta: { 
    backgroundColor: 'white', 
    padding: 25, 
    borderRadius: 20, 
    marginBottom: 25, 
    shadowColor: '#0f172a', 
    shadowOpacity: 0.05, 
    shadowRadius: 15, 
    elevation: 5, 
    minHeight: 100, 
    justifyContent: 'center' 
  },
  textoPergunta: { 
    fontSize: 20, 
    fontWeight: '800', 
    color: '#1e293b', 
    textAlign: 'center', 
    lineHeight: 28 
  },

  areaOpcoes: { 
    flex: 1 
  },
  botaoOpcao: { 
    backgroundColor: 'white', 
    padding: 18, 
    borderRadius: 15, 
    marginBottom: 12, 
    borderWidth: 2, 
    borderColor: '#e2e8f0' 
  },
  textoOpcao: { 
    fontSize: 16, 
    color: '#334155', 
    fontWeight: '600', 
    textAlign: 'center' 
  },
  botaoCorreto: { 
    backgroundColor: '#10b981', 
    borderColor: '#10b981' 
  },
  botaoIncorreto: { 
    backgroundColor: '#ef4444', 
    borderColor: '#ef4444' 
  },

  iconeGrande: { 
    fontSize: 80, 
    marginBottom: 20 
  },
  titulo: { 
    fontSize: 32, 
    fontWeight: '900', 
    color: '#0f172a', 
    marginBottom: 10 
  },
  subtitulo: { 
    fontSize: 18, 
    color: '#64748b', 
    marginBottom: 40 
  },
  botaoAcao: { 
    backgroundColor: '#3b82f6', 
    paddingVertical: 18, 
    paddingHorizontal: 40, 
    borderRadius: 16, 
    width: '100%', 
    maxWidth: 300, 
    alignItems: 'center' 
  },
  textoBotaoAcao: { 
    color: 'white', 
    fontSize: 18, 
    fontWeight: '800' 
  },
  textoCarregando: { 
    marginTop: 20, 
    fontSize: 18, 
    fontWeight: '600', 
    color: '#3b82f6' 
  }
});